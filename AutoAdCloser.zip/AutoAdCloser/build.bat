@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Python 3.10+ is needed ONLY to build the exe. Install it from https://www.python.org/downloads/
  echo and tick "Add python.exe to PATH", then run this file again.
  pause & exit /b 1
)
py -3 -m venv .venv || goto :fail
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip || goto :fail
pip install -r requirements.txt pyinstaller || goto :fail
pyinstaller --noconfirm --clean --onefile --windowed --name AutoAdCloser --exclude-module tkinter main.py || goto :fail
echo.
echo ==== DONE ====  Your app: %~dp0dist\AutoAdCloser.exe
explorer dist
pause & exit /b 0
:fail
echo Build failed - see messages above.
pause & exit /b 1
