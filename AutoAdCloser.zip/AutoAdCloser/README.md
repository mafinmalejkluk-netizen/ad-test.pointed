# Auto Ad Closer (Windows 10/11)

## Get the .exe (pick one)
**A. On your Windows PC:** install Python 3.10+ once (tick "Add to PATH"), double-click `build.bat`.
It creates `dist\AutoAdCloser.exe` - a single standalone file you can move anywhere. After that Python is not needed.

**B. No Python at all:** upload this folder to a GitHub repo -> Actions tab -> "Build Windows EXE" -> Run workflow ->
download the `AutoAdCloser-exe` artifact.

## Using it
1. Open the app, tick the programs (e.g. chrome.exe) in the list. Use search / Select All / Deselect All.
2. Tip: first enable **Detection & Safety -> Preview mode** and watch the Log tab, then turn it off.
3. Press **Start**. **Stop** ends gracefully; **Emergency Stop** (or **Ctrl+Shift+F12**) halts immediately.

## Safety built in
- Clicks only land if the pixel under the target belongs to a ticked app (re-checked right before the click).
- Title bars / tab strips are never scanned (so it can't close your browser or tabs); explorer/taskbar is excluded.
- Re-verifies the X is still there, multi-frame confirmation, per-minute click cap,
  repeated-spot blocker, pauses while you move the mouse, preview mode.

## Notes
- Settings, background photo and custom templates live in `%APPDATA%\AutoAdCloser`.
- To click inside programs running as administrator, run AutoAdCloser as administrator too.
- Ads whose close button is not an "X" shape (e.g. "Skip", "Close" text) need a PNG crop in the templates folder.
- Windows SmartScreen / some antivirus tools warn about unsigned PyInstaller exes; that is expected for self-built apps.
