"""Auto Ad Closer - detects "X" close buttons with OpenCV and clicks them,
but only inside applications you tick in the list. Windows 10/11, PySide6."""
import sys, os, json, math, time, ctypes, shutil, glob

import numpy as np
import cv2, mss, psutil
import win32gui, win32process, win32con
from PySide6 import QtCore, QtGui, QtWidgets
from PySide6.QtCore import Qt

APP_NAME = "Auto Ad Closer"
DATA_DIR = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "AutoAdCloser")
SETTINGS_FILE = os.path.join(DATA_DIR, "settings.json")
TEMPLATE_DIR = os.path.join(DATA_DIR, "templates")
os.makedirs(TEMPLATE_DIR, exist_ok=True)
OWN_PID = os.getpid()

# Never offered in the list and never clicked in (taskbar, desktop, shell, etc.)
HIDDEN_APPS = {"explorer.exe", "textinputhost.exe", "applicationframehost.exe", "searchhost.exe",
               "startmenuexperiencehost.exe", "shellexperiencehost.exe", "dwm.exe",
               "taskmgr.exe", "systemsettings.exe", "lockapp.exe", "logonui.exe"}

COLOR_KEYS = [("bg", "Background"), ("panel", "Panels"), ("text", "Text"), ("button", "Buttons"),
              ("button_text", "Button text"), ("border", "Borders"), ("accent", "Accent")]
THEMES = {
    "White": dict(bg="#f4f5f7", panel="#ffffff", text="#1b1b1f", button="#e6e8ec",
                  button_text="#1b1b1f", border="#cfd3da", accent="#2f7df6"),
    "Black": dict(bg="#0f1013", panel="#181a1f", text="#e8e9ee", button="#23262d",
                  button_text="#e8e9ee", border="#31353e", accent="#4aa3ff"),
    "Gray": dict(bg="#2b2d31", panel="#35383d", text="#e3e5e8", button="#43474e",
                 button_text="#e3e5e8", border="#555a63", accent="#7aa2f7"),
}
DEFAULTS = {
    "selected_apps": [],
    # speed
    "cursor_speed": 70, "click_delay_ms": 60, "reaction_ms": 150,
    "max_speed": False, "instant_click": True, "restore_cursor": True,
    # detection / safety
    "sensitivity": 80, "confirm_frames": 2, "max_clicks_per_min": 20,
    "preview_only": False, "only_foreground": False, "pause_on_user_input": True,
    "strict_isolation": True,
    # appearance
    "theme": "Black", "custom_colors": dict(THEMES["Black"]), "opacity": 100,
    "bg_image": "", "bg_dim": 60, "radius": 8, "always_on_top": False,
    "geometry": "",
    **THEMES["Black"],
}
APPEARANCE_KEYS = {"opacity", "bg_dim", "radius"} | {k for k, _ in COLOR_KEYS}


def load_settings():
    s = json.loads(json.dumps(DEFAULTS))
    try:
        with open(SETTINGS_FILE, encoding="utf-8") as f:
            s.update(json.load(f))
    except Exception:
        pass
    return s


def save_settings(s):
    try:
        tmp = SETTINGS_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(s, f, indent=2)
        os.replace(tmp, SETTINGS_FILE)
    except Exception:
        pass


# --------------------------------------------------------------------------- Win32 helpers
user32 = ctypes.windll.user32
dwmapi = ctypes.windll.dwmapi
winmm = ctypes.windll.winmm


class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


def get_cursor():
    p = POINT()
    user32.GetCursorPos(ctypes.byref(p))
    return p.x, p.y


def set_cursor(x, y):
    user32.SetCursorPos(int(x), int(y))


def mouse_click(fast=False):
    user32.mouse_event(0x0002, 0, 0, 0, 0)
    time.sleep(0.001 if fast else 0.01)
    user32.mouse_event(0x0004, 0, 0, 0, 0)


def key_down(vk):
    return bool(user32.GetAsyncKeyState(vk) & 0x8000)


def virtual_screen():
    g = user32.GetSystemMetrics
    return g(76), g(77), g(78), g(79)


def dpi_scale(h):
    try:
        return user32.GetDpiForWindow(ctypes.c_void_p(h)) / 96.0
    except Exception:
        return 1.0


def is_cloaked(h):
    v = ctypes.c_int(0)
    try:
        dwmapi.DwmGetWindowAttribute(ctypes.c_void_p(h), 14, ctypes.byref(v), 4)
    except Exception:
        return False
    return v.value != 0


_pname_cache = {}


def proc_name(pid):
    if len(_pname_cache) > 1000:
        _pname_cache.clear()
    n = _pname_cache.get(pid)
    if n is None:
        try:
            n = psutil.Process(pid).name().lower()
        except Exception:
            n = ""
        _pname_cache[pid] = n
    return n


class Win:
    __slots__ = ("hwnd", "pid", "name", "title", "rect")


def enum_windows(titles=False):
    out = []

    def cb(h, _):
        try:
            if not win32gui.IsWindowVisible(h) or win32gui.IsIconic(h) or is_cloaked(h):
                return True
            l, t, r, b = win32gui.GetWindowRect(h)
            if r - l < 120 or b - t < 100:
                return True
            pid = win32process.GetWindowThreadProcessId(h)[1]
            name = proc_name(pid)
            if not name:
                return True
            w = Win()
            w.hwnd, w.pid, w.name, w.rect = h, pid, name, (l, t, r, b)
            w.title = win32gui.GetWindowText(h) if titles else ""
            out.append(w)
        except Exception:
            pass
        return True

    win32gui.EnumWindows(cb, None)
    return out


# --------------------------------------------------------------------------- OpenCV detector
class Detector:
    """Finds small 'X' glyphs (dark-on-light or light-on-dark) via multi-scale template
    matching, then rejects look-alikes (letters inside text, photo noise) with checks.
    Put your own PNG crops of close buttons in the templates folder to extend it."""
    SIZES = {10: [1], 13: [1], 16: [1, 2], 20: [2], 25: [2, 3], 32: [2, 3]}

    def __init__(self):
        self.builtin = [(self._make_x(s, t), s) for s, ts in self.SIZES.items() for t in ts]
        self.custom = []
        for p in glob.glob(os.path.join(TEMPLATE_DIR, "*")):
            if p.lower().endswith((".png", ".jpg", ".jpeg", ".bmp")):
                try:
                    img = cv2.imdecode(np.fromfile(p, np.uint8), cv2.IMREAD_GRAYSCALE)
                    if img is not None and 6 <= max(img.shape) <= 120:
                        self.custom.append((img, max(img.shape)))
                except Exception:
                    pass

    @staticmethod
    def _make_x(s, t):
        pad = 2
        img = np.full((s + 2 * pad, s + 2 * pad), 255, np.uint8)
        cv2.line(img, (pad, pad), (pad + s - 1, pad + s - 1), 0, t, cv2.LINE_AA)
        cv2.line(img, (pad + s - 1, pad), (pad, pad + s - 1), 0, t, cv2.LINE_AA)
        return img

    def detect(self, gray, thr, strict=True):
        H, W = gray.shape
        cands = []
        for tpls, absval, custom in ((self.builtin, True, False), (self.custom, False, True)):
            for tpl, size in tpls:
                th, tw = tpl.shape
                if H < th or W < tw:
                    continue
                r = np.nan_to_num(cv2.matchTemplate(gray, tpl, cv2.TM_CCOEFF_NORMED))
                if absval:
                    r = np.abs(r)
                ys, xs = np.where(r >= thr)
                if len(ys) > 150:
                    top = np.argsort(r[ys, xs])[-150:]
                    ys, xs = ys[top], xs[top]
                for y, x in zip(ys, xs):
                    cands.append((float(r[y, x]), int(x + tw // 2), int(y + th // 2), size, custom))
        cands.sort(reverse=True)
        kept = []
        for c in cands:
            if any(math.hypot(c[1] - k[1], c[2] - k[2]) < max(c[3], k[3]) * 0.8 for k in kept):
                continue
            if not c[4] and not self._plausible(gray, c[1], c[2], c[3], strict):
                continue
            kept.append(c)
            if len(kept) >= 15:
                break
        return kept

    @staticmethod
    def _plausible(g, cx, cy, s, strict):
        H, W = g.shape
        h = s // 2
        y0, y1, x0, x1 = cy - h, cy + h + 1, cx - h, cx + h + 1
        if y0 < 0 or x0 < 0 or y1 > H or x1 > W:
            return False
        patch = g[y0:y1, x0:x1].astype(np.float32)
        n = patch.shape[0]
        if patch.shape[1] != n or n < 7:
            return False
        idx = np.arange(n)
        ii, jj = np.meshgrid(idx, idx, indexing="ij")
        d1, d2 = np.abs(ii - jj), np.abs(ii + jj - (n - 1))
        diag, off = (d1 <= 1) | (d2 <= 1), (d1 >= 3) & (d2 >= 3)
        if not diag.any() or not off.any():
            return False
        if abs(patch[diag].mean() - patch[off].mean()) < 35:    # X strokes must contrast
            return False
        if strict:                                              # must be an isolated glyph
            m = 3
            Y0, X0, Y1, X1 = max(0, y0 - m), max(0, x0 - m), min(H, y1 + m), min(W, x1 + m)
            reg = g[Y0:Y1, X0:X1].astype(np.float32)
            mask = np.ones(reg.shape, bool)
            mask[y0 - Y0:y1 - Y0, x0 - X0:x1 - X0] = False
            vals = reg[mask]
            if vals.size < 8 or vals.std() > 22:
                return False
        return True


# --------------------------------------------------------------------------- worker thread
class Worker(QtCore.QThread):
    status = QtCore.Signal(str)
    log = QtCore.Signal(str)
    clicked = QtCore.Signal(int)
    hotkey = QtCore.Signal()

    def __init__(self, settings, detector):
        super().__init__()
        self.s, self.det, self._run, self.total = settings, detector, True, 0

    def stop(self):
        self._run = False

    @staticmethod
    def _hot():                       # Ctrl + Shift + F12
        return key_down(0x11) and key_down(0x10) and key_down(0x7B)

    def _sleep(self, sec):
        end = time.perf_counter() + sec
        while self._run:
            left = end - time.perf_counter()
            if left <= 0:
                break
            time.sleep(min(0.01, left))

    def run(self):
        winmm.timeBeginPeriod(1)
        try:
            self._loop()
        except Exception as e:
            self.log.emit(f"Error: {e!r}")
        finally:
            winmm.timeEndPeriod(1)

    # -- safety: the pixel under the target must belong to a ticked application
    @staticmethod
    def _owned(x, y, sel):
        try:
            h = win32gui.WindowFromPoint((int(x), int(y)))
            if not h:
                return False
            root = win32gui.GetAncestor(h, win32con.GA_ROOT) or h
            pid = win32process.GetWindowThreadProcessId(root)[1]
            name = proc_name(pid)
            return pid != OWN_PID and name in sel and name not in HIDDEN_APPS
        except Exception:
            return False

    def _grab(self, sct, L, T, W, H):
        return cv2.cvtColor(np.asarray(sct.grab({"left": L, "top": T, "width": W, "height": H})),
                            cv2.COLOR_BGRA2GRAY)

    def _still(self, sct, q):
        S = self.s
        vx, vy, vw, vh = virtual_screen()
        r = int(q["size"]) + 10
        L, T = max(vx, q["x"] - r), max(vy, q["y"] - r)
        R, B = min(vx + vw, q["x"] + r), min(vy + vh, q["y"] + r)
        try:
            g = self._grab(sct, L, T, R - L, B - T)
        except Exception:
            return False
        thr = max(0.5, S["sensitivity"] / 100.0 - 0.05)
        return any(math.hypot(L + cx - q["x"], T + cy - q["y"]) <= 6
                   for _, cx, cy, _, _ in self.det.detect(g, thr, S["strict_isolation"]))

    def _move(self, x, y):
        S = self.s
        sx, sy = get_cursor()
        speed = S["cursor_speed"]
        if S["max_speed"] or speed >= 100:
            set_cursor(x, y)
            return True
        dist = math.hypot(x - sx, y - sy)
        dur = max(0.02, dist / (150 * 1.065 ** speed))       # px/s grows with the slider
        t0 = time.perf_counter()
        while True:
            if not self._run or self._hot():
                return False
            t = (time.perf_counter() - t0) / dur
            if t >= 1:
                break
            e = 1 - (1 - t) ** 2                              # ease-out
            set_cursor(sx + (x - sx) * e, sy + (y - sy) * e)
            time.sleep(0.004)
        set_cursor(x, y)
        return True

    def _click(self, q, sel, sct):
        S = self.s
        X, Y, mx = q["x"], q["y"], S["max_speed"]
        if S["preview_only"]:
            self.log.emit(f"[preview] X button at ({X},{Y}) score {q['score']:.2f}")
            return "preview"
        if not self._owned(X, Y, sel):
            self.log.emit("Skipped: target is not inside a selected application")
            return "skipped"
        if not self._still(sct, q):
            return "skipped"
        orig = get_cursor()
        if not self._move(X, Y):
            return "aborted"
        self._sleep(0 if mx else S["click_delay_ms"] / 1000.0)
        if not self._run or self._hot():
            return "aborted"
        if not self._owned(X, Y, sel):
            set_cursor(*orig)
            return "skipped"
        mouse_click(mx)
        if S["restore_cursor"]:
            set_cursor(*orig)
        return "clicked"

    def _loop(self):
        S = self.s
        tracks, blocked, spots, stamps = [], [], {}, []
        last_click, last_user, warned = 0.0, 0.0, False
        last_pos = get_cursor()
        with mss.mss() as sct:
            self.status.emit("Running")
            while self._run:
                if self._hot():
                    self.hotkey.emit()
                    return
                now = time.perf_counter()
                pos = get_cursor()
                if pos != last_pos:
                    last_user, last_pos = now, pos
                mx = S["max_speed"]
                if S["pause_on_user_input"] and not mx and now - last_user < 0.4:
                    self._sleep(0.05)
                    continue
                sel = {a.lower() for a in S["selected_apps"]} - HIDDEN_APPS
                if not sel:
                    self._sleep(0.3)
                    continue
                wins = [w for w in enum_windows() if w.name in sel and w.pid != OWN_PID]
                if S["only_foreground"]:
                    fg = win32gui.GetForegroundWindow()
                    wins = [w for w in wins if w.hwnd == fg]
                thr = S["sensitivity"] / 100.0
                reliable = max(thr + 0.08, 0.90)
                vx, vy, vw, vh = virtual_screen()
                new_tracks = []
                for w in wins:
                    if not self._run:
                        break
                    l, t, r, b = w.rect
                    top = t + int(40 * dpi_scale(w.hwnd))   # never scan the title bar / tab strip
                    L, T, R, B = max(l, vx), max(top, vy), min(r, vx + vw), min(b, vy + vh)
                    if R - L < 60 or B - T < 60:
                        continue
                    try:
                        gray = self._grab(sct, L, T, R - L, B - T)
                    except Exception:
                        continue
                    for score, cx, cy, size, _c in self.det.detect(gray, thr, S["strict_isolation"]):
                        X, Y = L + cx, T + cy
                        if any(math.hypot(X - bx, Y - by) < 12 for bx, by, _u in blocked):
                            continue
                        tr = next((q for q in tracks if q["hwnd"] == w.hwnd
                                   and abs(q["x"] - X) <= 6 and abs(q["y"] - Y) <= 6), None)
                        if tr is None:
                            tr = {"hwnd": w.hwnd, "n": 0}
                        tr.update(x=X, y=Y, score=score, size=size)
                        tr["n"] += 1
                        new_tracks.append(tr)
                tracks = new_tracks
                blocked = [b for b in blocked if b[2] > now]

                ready = [q for q in tracks if q["n"] >= (
                    1 if (S["instant_click"] and q["score"] >= reliable) else S["confirm_frames"])]
                if ready:
                    q = max(ready, key=lambda z: z["score"])
                    stamps = [x for x in stamps if now - x < 60]
                    if len(stamps) >= S["max_clicks_per_min"]:
                        if not warned:
                            self.log.emit("Rate limit reached - pausing clicks for a moment")
                            warned = True
                    elif now - last_click >= (0.05 if mx else 0.3):
                        warned = False
                        res = self._click(q, sel, sct)
                        last_pos = get_cursor()
                        if res == "clicked":
                            last_click = time.perf_counter()
                            stamps.append(last_click)
                            self.total += 1
                            self.clicked.emit(self.total)
                            self.log.emit(f"Clicked X at ({q['x']},{q['y']}) score {q['score']:.2f}")
                            key = (q["x"] // 12, q["y"] // 12)
                            hist = [x for x in spots.get(key, []) if now - x < 30] + [now]
                            spots[key] = hist
                            if len(hist) >= 3:       # same spot keeps coming back -> not an ad
                                blocked.append((q["x"], q["y"], now + 300))
                                self.log.emit("Spot ignored for 5 min (repeated clicks, likely not an ad)")
                            else:
                                blocked.append((q["x"], q["y"], now + 1.5))
                        else:
                            blocked.append((q["x"], q["y"], now + (2 if res == "preview" else 3)))
                self._sleep(0.001 if mx else max(0.005, S["reaction_ms"] / 1000.0))
        self.status.emit("Stopped")


# --------------------------------------------------------------------------- GUI
class BgWidget(QtWidgets.QWidget):
    def __init__(self, s):
        super().__init__()
        self.s, self.pix, self._cache = s, None, (None, None)

    def set_image(self, path):
        pm = QtGui.QPixmap(path) if path and os.path.exists(path) else QtGui.QPixmap()
        self.pix = None if pm.isNull() else pm
        self._cache = (None, None)
        self.update()
        return self.pix is not None

    def paintEvent(self, _):
        p = QtGui.QPainter(self)
        bg = QtGui.QColor(self.s["bg"])
        p.fillRect(self.rect(), bg)
        if self.pix:
            if self._cache[0] != self.size():
                self._cache = (self.size(), self.pix.scaled(
                    self.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation))
            sc = self._cache[1]
            p.drawPixmap((self.width() - sc.width()) // 2, (self.height() - sc.height()) // 2, sc)
            bg.setAlpha(int(255 * self.s["bg_dim"] / 100))
            p.fillRect(self.rect(), bg)


def rgba(hexcol, a):
    c = QtGui.QColor(hexcol)
    return f"rgba({c.red()},{c.green()},{c.blue()},{a})"


def build_qss(s, has_bg):
    panel = rgba(s["panel"], 205 if has_bg else 255)
    r, ac, bd = s["radius"], s["accent"], s["border"]
    return f"""
    QWidget {{ color:{s['text']}; font-family:'Segoe UI'; font-size:9pt; }}
    QFrame#card {{ background:{panel}; border:1px solid {bd}; border-radius:{r}px; }}
    QScrollArea, QScrollArea > QWidget > QWidget {{ background:transparent; border:none; }}
    QPushButton {{ background:{s['button']}; color:{s['button_text']}; border:1px solid {bd};
                  border-radius:{r}px; padding:5px 12px; }}
    QPushButton:hover {{ border-color:{ac}; }}
    QPushButton:pressed {{ background:{ac}; color:#ffffff; }}
    QPushButton:disabled {{ color:#888888; }}
    QPushButton#startBtn {{ background:{ac}; color:#ffffff; border-color:{ac}; font-weight:600; }}
    QPushButton#startBtn:disabled {{ background:{s['button']}; color:#888888; border-color:{bd}; }}
    QPushButton#emergencyBtn {{ background:#d93025; color:#ffffff; border-color:#d93025; font-weight:600; }}
    QLineEdit, QComboBox {{ background:{panel}; border:1px solid {bd}; border-radius:{r}px; padding:4px 8px; }}
    QComboBox QAbstractItemView {{ background:{s['panel']}; color:{s['text']}; selection-background-color:{ac}; }}
    QListWidget, QPlainTextEdit {{ background:transparent; border:none; }}
    QListWidget::item {{ padding:3px 2px; border-radius:4px; }}
    QListWidget::item:hover {{ background:{rgba(ac, 50)}; }}
    QTabWidget::pane {{ background:{panel}; border:1px solid {bd}; border-radius:{r}px; top:-1px; }}
    QTabBar::tab {{ background:transparent; padding:6px 12px; border:none; border-bottom:2px solid transparent; }}
    QTabBar::tab:selected {{ border-bottom:2px solid {ac}; font-weight:600; }}
    QSlider::groove:horizontal {{ height:4px; background:{bd}; border-radius:2px; }}
    QSlider::sub-page:horizontal {{ background:{ac}; border-radius:2px; }}
    QSlider::handle:horizontal {{ background:{ac}; width:14px; height:14px; margin:-6px 0; border-radius:7px; }}
    QSlider:disabled::sub-page:horizontal {{ background:{bd}; }}
    QCheckBox::indicator, QListWidget::indicator {{ width:15px; height:15px; border:1px solid {bd};
                  border-radius:4px; background:{panel}; }}
    QCheckBox::indicator:checked, QListWidget::indicator:checked {{ background:{ac}; border-color:{ac}; }}
    QScrollBar:vertical {{ width:8px; background:transparent; }}
    QScrollBar::handle:vertical {{ background:{bd}; border-radius:4px; min-height:20px; }}
    QScrollBar::add-line, QScrollBar::sub-line {{ height:0; width:0; }}
    QToolTip {{ background:{s['panel']}; color:{s['text']}; border:1px solid {bd}; }}
    """


def scroll(widget):
    sa = QtWidgets.QScrollArea()
    sa.setWidgetResizable(True)
    sa.setFrameShape(QtWidgets.QFrame.NoFrame)
    sa.setWidget(widget)
    return sa


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.s = load_settings()
        self.worker, self._emerg, self.detector = None, False, None
        self.setWindowTitle(APP_NAME)
        self.setMinimumSize(660, 300)
        self.resize(880, 350)
        if self.s["geometry"]:
            self.restoreGeometry(QtCore.QByteArray.fromBase64(self.s["geometry"].encode()))
        self.save_timer = QtCore.QTimer(self, singleShot=True, interval=400)
        self.save_timer.timeout.connect(self.save_now)

        self.bg = BgWidget(self.s)
        self.setCentralWidget(self.bg)
        root = QtWidgets.QVBoxLayout(self.bg)
        root.setContentsMargins(12, 10, 12, 8)
        root.setSpacing(8)

        # top bar
        top = QtWidgets.QHBoxLayout()
        self.btn_start = QtWidgets.QPushButton("▶  Start")
        self.btn_start.setObjectName("startBtn")
        self.btn_stop = QtWidgets.QPushButton("■  Stop")
        self.btn_emerg = QtWidgets.QPushButton("⛔  Emergency Stop")
        self.btn_emerg.setObjectName("emergencyBtn")
        self.btn_emerg.setToolTip("Stops instantly. Hotkey: Ctrl + Shift + F12")
        self.lbl_status = QtWidgets.QLabel("● Idle")
        self.lbl_clicks = QtWidgets.QLabel("Clicks: 0")
        for b in (self.btn_start, self.btn_stop, self.btn_emerg):
            top.addWidget(b)
        top.addStretch(1)
        top.addWidget(self.lbl_status)
        top.addSpacing(12)
        top.addWidget(self.lbl_clicks)
        root.addLayout(top)
        self.btn_stop.setEnabled(False)
        self.btn_start.clicked.connect(self.start)
        self.btn_stop.clicked.connect(self.stop)
        self.btn_emerg.clicked.connect(self.emergency)

        # body
        body = QtWidgets.QHBoxLayout()
        body.setSpacing(10)
        body.addWidget(self._apps_panel(), 4)
        tabs = QtWidgets.QTabWidget()
        tabs.addTab(scroll(self._tab_speed()), "Speed")
        tabs.addTab(scroll(self._tab_safety()), "Detection && Safety")
        tabs.addTab(scroll(self._tab_appearance()), "Appearance")
        tabs.addTab(self._tab_log(), "Log")
        body.addWidget(tabs, 6)
        root.addLayout(body, 1)
        hint = QtWidgets.QLabel("Emergency hotkey: Ctrl + Shift + F12   ·   Settings are saved automatically")
        hint.setStyleSheet("font-size:8pt; color:gray;")
        root.addWidget(hint)

        self.bg.set_image(self.s["bg_image"])
        self.apply_theme()
        if self.s["always_on_top"]:
            self.setWindowFlag(Qt.WindowStaysOnTopHint, True)
        self.refresh_apps()
        self.app_timer = QtCore.QTimer(self, interval=3000)
        self.app_timer.timeout.connect(self.refresh_apps)
        self.app_timer.start()

    # ---- generic helpers
    def save_soon(self):
        self.save_timer.start()

    def save_now(self):
        self.s["geometry"] = bytes(self.saveGeometry().toBase64()).decode()
        save_settings(self.s)

    def changed(self, key=None):
        if key in APPEARANCE_KEYS:
            self.apply_theme()
        self.save_soon()

    def apply_theme(self):
        self.setStyleSheet(build_qss(self.s, self.bg.pix is not None))
        self.setWindowOpacity(self.s["opacity"] / 100.0)
        self.bg.update()

    def _slider(self, grid, row, label, key, lo, hi, fmt):
        sl = QtWidgets.QSlider(Qt.Horizontal)
        sl.setRange(lo, hi)
        sl.setValue(int(self.s[key]))
        val = QtWidgets.QLabel(fmt(self.s[key]))
        val.setMinimumWidth(90)

        def on(v):
            self.s[key] = v
            val.setText(fmt(v))
            self.changed(key)
        sl.valueChanged.connect(on)
        grid.addWidget(QtWidgets.QLabel(label), row, 0)
        grid.addWidget(sl, row, 1)
        grid.addWidget(val, row, 2)
        return sl

    def _check(self, grid, row, label, key, tip="", cb=None):
        c = QtWidgets.QCheckBox(label)
        c.setChecked(bool(self.s[key]))
        c.setToolTip(tip)

        def on(v):
            self.s[key] = bool(v)
            if cb:
                cb()
            self.changed(key)
        c.toggled.connect(on)
        grid.addWidget(c, row, 0, 1, 3)
        return c

    # ---- apps panel
    def _apps_panel(self):
        card = QtWidgets.QFrame()
        card.setObjectName("card")
        lay = QtWidgets.QVBoxLayout(card)
        lay.setContentsMargins(10, 10, 10, 10)
        self.search = QtWidgets.QLineEdit()
        self.search.setPlaceholderText("🔍  Search applications…")
        self.search.textChanged.connect(self.apply_filter)
        self.list = QtWidgets.QListWidget()
        self.list.itemChanged.connect(self.apps_changed)
        row = QtWidgets.QHBoxLayout()
        b_all, b_none, b_ref = (QtWidgets.QPushButton("Select All"), QtWidgets.QPushButton("Deselect All"),
                                QtWidgets.QPushButton("⟳"))
        b_ref.setToolTip("Refresh list")
        b_all.clicked.connect(lambda: self.set_all(True))
        b_none.clicked.connect(lambda: self.set_all(False))
        b_ref.clicked.connect(self.refresh_apps)
        for b in (b_all, b_none, b_ref):
            row.addWidget(b)
        lay.addWidget(self.search)
        lay.addWidget(self.list, 1)
        lay.addLayout(row)
        return card

    def refresh_apps(self):
        found = {}
        for w in enum_windows(titles=True):
            if w.pid != OWN_PID and w.name not in HIDDEN_APPS and w.title:
                found.setdefault(w.name, w.title)
        sel = {a.lower() for a in self.s["selected_apps"]}
        names = sorted(set(found) | sel)
        cur = [self.list.item(i).data(Qt.UserRole) for i in range(self.list.count())]
        if names == cur:
            return
        self.list.blockSignals(True)
        self.list.clear()
        for n in names:
            it = QtWidgets.QListWidgetItem(f"{n}   —   {found[n][:34]}" if n in found else f"{n}   (not running)")
            it.setData(Qt.UserRole, n)
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Checked if n in sel else Qt.Unchecked)
            self.list.addItem(it)
        self.list.blockSignals(False)
        self.apply_filter()

    def apply_filter(self):
        t = self.search.text().lower().strip()
        for i in range(self.list.count()):
            it = self.list.item(i)
            it.setHidden(bool(t) and t not in it.text().lower())

    def set_all(self, on):
        self.list.blockSignals(True)
        for i in range(self.list.count()):
            it = self.list.item(i)
            if not it.isHidden():
                it.setCheckState(Qt.Checked if on else Qt.Unchecked)
        self.list.blockSignals(False)
        self.apps_changed()

    def apps_changed(self, *_):
        self.s["selected_apps"] = sorted(
            self.list.item(i).data(Qt.UserRole) for i in range(self.list.count())
            if self.list.item(i).checkState() == Qt.Checked)
        self.save_soon()

    # ---- tabs
    def _tab_speed(self):
        w = QtWidgets.QWidget()
        g = QtWidgets.QGridLayout(w)
        g.setColumnStretch(1, 1)
        self.speed_sliders = [
            self._slider(g, 0, "Cursor speed", "cursor_speed", 1, 100,
                         lambda v: "Instant" if v >= 100 else ("Slow" if v < 25 else "Fast" if v > 75 else "Medium") + f" ({v})"),
            self._slider(g, 1, "Click delay", "click_delay_ms", 0, 1000, lambda v: f"{v} ms"),
            self._slider(g, 2, "Reaction time", "reaction_ms", 0, 2000,
                         lambda v: "Continuous" if v == 0 else f"{v} ms"),
        ]
        g.addWidget(QtWidgets.QLabel("Reaction time = how often the screen is scanned (lower = faster, more CPU)."), 3, 0, 1, 3)
        self._check(g, 4, "⚡ Maximum-speed mode", "max_speed",
                    "Continuous scanning, no delays, cursor teleports. Safety checks stay on.",
                    self._speed_enable)
        self._check(g, 5, "Instant click when a close button is reliably detected", "instant_click",
                    "Skips the multi-frame confirmation for very high-confidence matches.")
        self._check(g, 6, "Return cursor to its original position after clicking", "restore_cursor")
        g.setRowStretch(7, 1)
        self._speed_enable()
        return w

    def _speed_enable(self):
        for sl in self.speed_sliders:
            sl.setEnabled(not self.s["max_speed"])

    def _tab_safety(self):
        w = QtWidgets.QWidget()
        g = QtWidgets.QGridLayout(w)
        g.setColumnStretch(1, 1)
        self._slider(g, 0, "Sensitivity", "sensitivity", 60, 98, lambda v: f"{v} % match")
        self._slider(g, 1, "Confirm frames", "confirm_frames", 1, 5, lambda v: f"{v} scan(s)")
        self._slider(g, 2, "Max clicks / minute", "max_clicks_per_min", 1, 120, lambda v: str(v))
        self._check(g, 3, "Preview mode (detect only, never click)", "preview_only",
                    "Shows detections in the Log tab - good for testing.")
        self._check(g, 4, "Only the window I'm currently using (foreground)", "only_foreground")
        self._check(g, 5, "Pause while I'm moving the mouse", "pause_on_user_input")
        self._check(g, 6, "Strict check: X must be an isolated symbol", "strict_isolation",
                    "Rejects letters in text and noisy images. Turn off if real ads are missed.")
        b = QtWidgets.QPushButton("Open custom templates folder…")
        b.setToolTip("Drop PNG crops of close buttons here; they are loaded on the next Start.")
        b.clicked.connect(lambda: os.startfile(TEMPLATE_DIR))
        g.addWidget(b, 7, 0, 1, 3)
        g.addWidget(QtWidgets.QLabel("Always applied: window title bars/tab strips are never scanned, clicks only land in ticked apps, "
                                     "targets are re-verified before clicking, repeated spots are ignored."), 8, 0, 1, 3)
        g.itemAtPosition(8, 0).widget().setWordWrap(True)
        g.setRowStretch(9, 1)
        return w

    def _tab_appearance(self):
        w = QtWidgets.QWidget()
        g = QtWidgets.QGridLayout(w)
        g.setColumnStretch(1, 1)
        g.addWidget(QtWidgets.QLabel("Theme"), 0, 0)
        self.theme_combo = QtWidgets.QComboBox()
        self.theme_combo.addItems(["White", "Black", "Gray", "Custom"])
        self.theme_combo.setCurrentText(self.s["theme"])
        self.theme_combo.currentTextChanged.connect(self.on_theme)
        g.addWidget(self.theme_combo, 0, 1, 1, 2)
        self.swatches = {}
        sw = QtWidgets.QGridLayout()
        for i, (k, label) in enumerate(COLOR_KEYS):
            b = QtWidgets.QPushButton()
            b.setFixedSize(34, 22)
            b.clicked.connect(lambda _=False, key=k: self.pick_color(key))
            self.swatches[k] = b
            sw.addWidget(QtWidgets.QLabel(label), i // 2, (i % 2) * 2)
            sw.addWidget(b, i // 2, (i % 2) * 2 + 1)
        g.addLayout(sw, 1, 0, 1, 3)
        self._paint_swatches()
        self._slider(g, 2, "Window transparency", "opacity", 30, 100, lambda v: f"{v} % opaque")
        self._slider(g, 3, "Corner roundness", "radius", 0, 20, lambda v: f"{v} px")
        self._slider(g, 4, "Background dimming", "bg_dim", 0, 95, lambda v: f"{v} %")
        row = QtWidgets.QHBoxLayout()
        b1, b2 = QtWidgets.QPushButton("Choose background photo…"), QtWidgets.QPushButton("Remove photo")
        b1.clicked.connect(self.choose_bg)
        b2.clicked.connect(self.remove_bg)
        row.addWidget(b1)
        row.addWidget(b2)
        g.addLayout(row, 5, 0, 1, 3)
        self._check(g, 6, "Always on top", "always_on_top", cb=lambda: self.set_on_top(self.s["always_on_top"]))
        g.setRowStretch(7, 1)
        return w

    def _tab_log(self):
        self.logbox = QtWidgets.QPlainTextEdit()
        self.logbox.setReadOnly(True)
        self.logbox.setMaximumBlockCount(300)
        return self.logbox

    # ---- appearance actions
    def _paint_swatches(self):
        for k, b in self.swatches.items():
            b.setStyleSheet(f"background:{self.s[k]}; border:1px solid #888; border-radius:6px;")

    def on_theme(self, name):
        cols = self.s["custom_colors"] if name == "Custom" else THEMES[name]
        self.s["theme"] = name
        self.s.update({k: cols[k] for k, _ in COLOR_KEYS})
        self._paint_swatches()
        self.apply_theme()
        self.save_soon()

    def pick_color(self, key):
        c = QtWidgets.QColorDialog.getColor(QtGui.QColor(self.s[key]), self, "Choose color")
        if not c.isValid():
            return
        self.s[key] = c.name()
        self.s["theme"] = "Custom"
        self.s["custom_colors"] = {k: self.s[k] for k, _ in COLOR_KEYS}
        self.theme_combo.blockSignals(True)
        self.theme_combo.setCurrentText("Custom")
        self.theme_combo.blockSignals(False)
        self._paint_swatches()
        self.apply_theme()
        self.save_soon()

    def choose_bg(self):
        p, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Choose background photo", "",
                                                     "Images (*.png *.jpg *.jpeg *.bmp *.webp)")
        if not p:
            return
        dest = os.path.join(DATA_DIR, "background" + os.path.splitext(p)[1].lower())
        try:
            shutil.copyfile(p, dest)
        except Exception:
            dest = p
        if self.bg.set_image(dest):
            self.s["bg_image"] = dest
            self.apply_theme()
            self.save_soon()
        else:
            QtWidgets.QMessageBox.warning(self, APP_NAME, "That image could not be loaded.")

    def remove_bg(self):
        self.s["bg_image"] = ""
        self.bg.set_image("")
        self.apply_theme()
        self.save_soon()

    def set_on_top(self, on):
        vis = self.isVisible()
        self.setWindowFlag(Qt.WindowStaysOnTopHint, bool(on))
        if vis:
            self.show()

    # ---- run control
    def add_log(self, msg):
        self.logbox.appendPlainText(time.strftime("%H:%M:%S  ") + msg)

    def set_status(self, text, color):
        self.lbl_status.setText("● " + text)
        self.lbl_status.setStyleSheet(f"color:{color}; font-weight:600;")

    def start(self):
        if self.worker and self.worker.isRunning():
            return
        if not self.s["selected_apps"]:
            QtWidgets.QMessageBox.information(self, APP_NAME, "Tick at least one application first.")
            return
        self._emerg = False
        self.detector = Detector()
        self.worker = Worker(self.s, self.detector)
        self.worker.status.connect(lambda t: self.set_status(t, "#2ea043"))
        self.worker.log.connect(self.add_log)
        self.worker.clicked.connect(lambda n: self.lbl_clicks.setText(f"Clicks: {n}"))
        self.worker.hotkey.connect(self.emergency)
        self.worker.finished.connect(self.worker_done)
        self.lbl_clicks.setText("Clicks: 0")
        self.worker.start()
        self.btn_start.setEnabled(False)
        self.btn_stop.setEnabled(True)
        self.add_log(f"Started ({len(self.detector.custom)} custom templates)"
                     + (" - PREVIEW mode" if self.s["preview_only"] else ""))

    def stop(self):
        if self.worker:
            self.worker.stop()

    def emergency(self):
        self._emerg = True
        if self.worker:
            self.worker.stop()
            self.worker.wait(1500)
        self.set_status("EMERGENCY STOP - press Start to resume", "#d93025")
        self.add_log("EMERGENCY STOP")
        self.worker_done()

    def worker_done(self):
        self.btn_start.setEnabled(True)
        self.btn_stop.setEnabled(False)
        if not self._emerg:
            self.set_status("Stopped", "#c9a227")

    def closeEvent(self, e):
        self.app_timer.stop()
        if self.worker and self.worker.isRunning():
            self.worker.stop()
            self.worker.wait(2000)
        self.save_now()
        super().closeEvent(e)


def main():
    if sys.platform != "win32":
        print("This application only runs on Windows 10/11.")
        return 1
    app = QtWidgets.QApplication(sys.argv)
    app.setStyle("Fusion")
    app.setApplicationName(APP_NAME)
    w = MainWindow()
    w.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
